package exception;

public class FileNameAlreadyExistsException extends Exception{
}

﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Bank;
using System;

namespace BankTest
{
    [TestClass]
    public class BankAccountTests
    {
        [TestMethod]
        public void Debit_WithValidAmount_UpdatesBalance()
        {
            // Arrange
            double beginningBalance = 11.99;
            double debitAmount = 4.55;
            double expected = 7.44;
            BankAccount account = new BankAccount("Mr. Bryan Walton", beginningBalance);

            // Act
            account.Debit(debitAmount);

            // Assert
            double actual = account.Balance;
            Assert.AreEqual(expected, actual, 0.001, "Account not debited correctly");
        }

        [TestMethod]
        public void Debit_WhenAmountIsLessThanZero_ShouldThrowArgumentOutOfRange()
        {
            // Arrange
            double beginningBalance = 11.99;
            double debitAmount = -100.00;
            BankAccount account = new BankAccount("Mr. Bryan Walton", beginningBalance);

            // Act and assert
            Assert.ThrowsException<System.ArgumentOutOfRangeException>(() => account.Debit(debitAmount));
        }

        [TestMethod]
        public void Debit_WhenAmountIsMoreThanBalance_ShouldThrowArgumentOutOfRange()
        {
            // Arrange
            double beginningBalance = 11.99;
            double debitAmount = 20.0;
            BankAccount account = new BankAccount("Mr. Bryan Walton", beginningBalance);

            // Act
            try
            {
                account.Debit(debitAmount);
            }
            catch (System.ArgumentOutOfRangeException e)
            {
                // Assert
                StringAssert.Contains(e.Message, BankAccount.DebitAmountExceedsBalanceMessage);
                return;
            }

            Assert.Fail("The expected exception was not thrown.");
        }

        // Далее идут методы, написанные мной

        // Тест на исключение при попытке снять отрицательную сумму
        [TestMethod]
        public void Debit_WhenAmountIsNegative_ShouldThrowArgumentOutOfRange()
        {
            // Arrange
            BankAccount account = new BankAccount("Test User", 10.0);
            double debitAmount = -1.0;

            // Act & Assert
            try
            {
                account.Debit(debitAmount);
            }
            catch (ArgumentOutOfRangeException ex)
            {
                StringAssert.Contains(ex.Message, BankAccount.DebitAmountLessThanZeroMessage);
                return;
            }
            Assert.Fail("Expected exception was not thrown.");
        }

        // Тест на зачисление очень большой суммы
        [TestMethod]
        public void Credit_WithLargeAmount_IncreasesBalanceCorrectly()
        {
            // Arrange
            double beginningBalance = 1000.0;
            double creditAmount = 1_000_000.0;
            BankAccount account = new BankAccount("Test User", beginningBalance);

            // Act
            account.Credit(creditAmount);

            // Assert
            double expected = 1_001_000.0;
            Assert.AreEqual(expected, account.Balance, 0.001, "Баланс должен корректно увеличиться после зачисления большой суммы");
        }

        // Тест проверки имени клиента (свойство CustomerName)
        [TestMethod]
        public void CustomerName_ReturnsCorrectName()
        {
            // Arrange
            string expectedName = "John Doe";
            BankAccount account = new BankAccount(expectedName, 0);

            // Act
            string actualName = account.CustomerName;

            // Assert
            Assert.AreEqual(expectedName, actualName, "CustomerName property should return the correct name");
        }
    }
}
